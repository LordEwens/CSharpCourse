﻿// Creator: David Ewens, Class 7A
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_CSharpGund
{
    class Program
    {
        private static void RunExerciseOne()
        {
            string firstName = "David", lastName = "Ewens";
            Console.WriteLine("Hello {0} {1}! I'm glad to inform you that you are the test subject of my very first assignment!", firstName, lastName);
        }

        private static void RunExerciseTwo()
        {
            string fullName;
            Console.WriteLine("What is your full name?");
            fullName = Console.ReadLine();
            Console.WriteLine("Hello {0}! Have a nice day!", fullName);
        }

        private static void RunExerciseThree()
        {
            int birthYear, birthMonth, birthDay;
            DateTime currentDate = DateTime.Now;
            
            Console.WriteLine("What year were you born? Example, 1989");
            birthYear = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("What month were you born? Example, 10");
            birthMonth = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("What day were you born? Example, 29");
            birthDay = Convert.ToInt32(Console.ReadLine());
            DateTime birthDate = new DateTime(birthYear, birthMonth, birthDay);
            TimeSpan age = currentDate.Subtract(birthDate);
            Console.WriteLine("Your current age is: {0}", (Int32)(age.TotalDays/365));

        }

        private static void RunExerciseFour()
        {
            
        }

        private static void RunExerciseFive()
        {

        }
        private static void RunExerciseSix()
        {

        }

        private static void RunExerciseSeven()
        {

        }
        private static void RunExerciseEight()
        {

        }
        private static void RunExerciseNine()
        {

        }

        static void Main(string[] args)
        {
            






           
            bool keepAlive = true;
            while (keepAlive)
            {
                try
                {
                    Console.Write("Enter assignment number (or -1 to exit): ");
                    var assignmentChoice = int.Parse(Console.ReadLine() ?? "");
                    Console.ForegroundColor = ConsoleColor.Green;
                    switch (assignmentChoice)
                    {
                        case 1:
                            RunExerciseOne();
                            break;
                        case 2:
                            RunExerciseTwo();
                            break;
                        case 3:
                            RunExerciseThree();
                            break;
                        case 4:
                            RunExerciseFour();
                            break;
                        case 5:
                            RunExerciseFive();
                            break;
                        case 6:
                            RunExerciseSix();
                            break;
                        case 7:
                            RunExerciseSeven();
                            break;
                        case 8:
                            RunExerciseEight();
                            break;
                        case 9:
                            RunExerciseNine();
                            break;
                        case -1:
                            keepAlive = false;
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("That is not a valid assignment number!");
                            break;
                    }
                    Console.ResetColor();
                    Console.WriteLine("Hit any key to continue..");
                    Console.ReadKey();
                    Console.Clear();
                }
                catch (Exception e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
            }

        }

    }
}
